## FisioRangers
### Grupo D
Projeto Final de Banco de Dados II, do Centro Universitário SATC, voltado para o atendimento de clinicas fisioterapêuticas.
### Integrantes:
Gabriel Tarciso Macieiski <br>
Jefferson Barzan Alexandrino <br>
João Eduardo Milak Farias <br>
João Vittor Gomes Fernandes <br>
Maria Eduarda Monteiro Marcos <br>
Maria Luíza Arend da Silva <br>

### Modelo Físico:
Utilizado https://xxxxxxxxxxxx/<br>
Arquivo fonte: <code>link pro arquivo</code><br>
<code>Imagem</code>
  
### Dicionário de Dados:
<code>Excel ou tabela do Github (markdown)</code>

### Scripts DDL Criação do Database:
Banco de dados utilizado SQL Server versão 2022 - Azure.<br>
<code>1 arquivo SQL por objeto</code>

### Scripts Popula tabelas:
Banco de dados utilizado SQL Server versão 2022 - Azure.<br>
<code>1 arquivo SQL por objeto</code>

### Objetos de BD (stored procedure, triggers e functions):
<code>1 arquivo SQL por objeto</code>
  
### Código do sistema:
Linguagem de Programação C# .NET.<br>
<code>código fonte da aplicação</code>
